<html>
<head>
  <style>
  #footer {

  position:absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 75px;
  background-color:#000000;
  color:white;
  text-align: center;
}
  </style>
</head>
<body>
  <div id="footer" >
  <b><center>COPYRIGHT © 2020<br>
  Blood Bank & Donation Management
  <br>
  ALL RIGHTS RESERVED.
  </center>
  </div>


</body>

</html>
